Name: Christopher Boyd
St #: 216 869 356
York: chris360

Note: I used the definitions of turnaround, waiting and response time
from the textbook. I did find some slightly varying definitions for the 
formulas online.

Turnaround time – the interval from the time of submission of a process to the time of completion (including I/O, thus depends on speed of I/O).

Waiting time – sum of the amounts of time that a process has spent waiting in the ready queue

Response time – amount of time it takes from when a request was submitted until the first response is produced (ie until the process first leaves the queue to be run)